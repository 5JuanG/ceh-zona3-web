import React, { useState, useEffect } from 'react';
import { InteractiveMap } from './InteractiveMap';
import { useApp } from '../context/AppContext';
import { Hospital } from '../types';
import {
  resolveAndParseGoogleMapsUrl,
  getCityFallbackCoordinates,
  sanitizeHospitalCoordinates
} from '../utils/googleMapsParser';

interface HospitalModalProps {
  isOpen: boolean;
  onClose: () => void;
  hospitalToEdit?: Hospital | null;
}

const emptyForm = {
  name: '',
  shortName: '',
  zone: 'Zona 3',
  type: 'privado' as Hospital['type'],
  address: '',
  city: '',
  phoneEmergency: '',
  phoneGeneral: '',
  email: '',
  website: '',
  contactPerson: '',
  congregationNumber: '',
  notes: '',
  pbmProtocolsAccepted: false,
  acceptsBloodlessSurgery: false,
  googleMapsUrl: ''
};

export const HospitalModal: React.FC<HospitalModalProps> = ({ isOpen, onClose, hospitalToEdit }) => {
  const { addHospital, updateHospital } = useApp();

  const [form, setForm] = useState(emptyForm);
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null);
  const [resolvingLink, setResolvingLink] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (hospitalToEdit) {
      setForm({
        name: hospitalToEdit.name || '',
        shortName: hospitalToEdit.shortName || '',
        zone: hospitalToEdit.zone || 'Zona 3',
        type: hospitalToEdit.type || 'privado',
        address: hospitalToEdit.address || '',
        city: hospitalToEdit.city || '',
        phoneEmergency: hospitalToEdit.phoneEmergency || '',
        phoneGeneral: hospitalToEdit.phoneGeneral || '',
        email: hospitalToEdit.email || '',
        website: hospitalToEdit.website || '',
        contactPerson: hospitalToEdit.contactPerson || '',
        congregationNumber: hospitalToEdit.congregationNumber || '',
        notes: hospitalToEdit.notes || '',
        pbmProtocolsAccepted: !!hospitalToEdit.pbmProtocolsAccepted,
        acceptsBloodlessSurgery: !!hospitalToEdit.acceptsBloodlessSurgery,
        googleMapsUrl: hospitalToEdit.googleMapsUrl || ''
      });
      setCoordinates(hospitalToEdit.coordinates || null);
    } else {
      setForm(emptyForm);
      setCoordinates(null);
    }
    setError('');
  }, [isOpen, hospitalToEdit]);

  if (!isOpen) return null;

  const setField = (field: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const value = e.target.type === 'checkbox' ? (e.target as HTMLInputElement).checked : e.target.value;
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleResolveLink = async () => {
    if (!form.googleMapsUrl.trim()) return;
    setResolvingLink(true);
    setError('');
    try {
      const parsed = await resolveAndParseGoogleMapsUrl(form.googleMapsUrl);
      if (parsed.coordinates) {
        setCoordinates(parsed.coordinates);
      } else {
        setError('No se pudo obtener la ubicación exacta de ese enlace. Puedes marcarla manualmente en el mapa.');
      }
      if (parsed.extractedName && !form.name) {
        setForm(prev => ({ ...prev, name: parsed.extractedName! }));
      }
      if (parsed.extractedAddress && !form.address) {
        setForm(prev => ({ ...prev, address: parsed.extractedAddress! }));
      }
      if (parsed.extractedCity && !form.city) {
        setForm(prev => ({ ...prev, city: parsed.extractedCity! }));
      }
    } catch {
      setError('No se pudo procesar ese enlace. Puedes marcar la ubicación manualmente en el mapa.');
    } finally {
      setResolvingLink(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!form.name.trim() || !form.address.trim() || !form.city.trim() || !form.phoneEmergency.trim()) {
      setError('Completa al menos Nombre, Dirección, Ciudad y Teléfono de urgencias.');
      return;
    }

    // Si no se marcó una ubicación exacta, usamos una aproximada según la ciudad
    // en vez de dejar el hospital sin coordenadas (lo que lo dejaría invisible en el mapa).
    const finalCoordinates =
      sanitizeHospitalCoordinates(coordinates) || getCityFallbackCoordinates(form.city);

    const payload: Omit<Hospital, 'id' | 'createdAt'> = {
      name: form.name.trim(),
      shortName: form.shortName.trim() || undefined,
      zone: form.zone.trim() || 'Zona 3',
      type: form.type,
      address: form.address.trim(),
      city: form.city.trim(),
      phoneEmergency: form.phoneEmergency.trim(),
      phoneGeneral: form.phoneGeneral.trim(),
      email: form.email.trim() || undefined,
      website: form.website.trim() || undefined,
      contactPerson: form.contactPerson.trim() || undefined,
      congregationNumber: form.congregationNumber.trim() || undefined,
      notes: form.notes.trim(),
      pbmProtocolsAccepted: form.pbmProtocolsAccepted,
      acceptsBloodlessSurgery: form.acceptsBloodlessSurgery,
      googleMapsUrl: form.googleMapsUrl.trim() || undefined,
      coordinates: finalCoordinates
    };

    if (hospitalToEdit) {
      updateHospital(hospitalToEdit.id, payload);
    } else {
      addHospital(payload);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 overflow-y-auto backdrop-blur-xs">
      <form
        onSubmit={handleSubmit}
        className="bg-white rounded-xl max-w-4xl w-full shadow-2xl flex flex-col max-h-[92vh] border border-gray-200 animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Cabecera */}
        <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-slate-900 text-white rounded-t-xl">
          <h3 className="font-bold text-sm sm:text-base flex items-center gap-2">
            🏥 {hospitalToEdit ? 'Editar Hospital de la Zona' : 'Registrar Nuevo Hospital de la Zona'}
          </h3>
          <button type="button" onClick={onClose} className="text-gray-400 hover:text-white transition text-sm px-2 cursor-pointer">
            ✕
          </button>
        </div>

        {/* Cuerpo */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4 bg-slate-50 max-h-[calc(92vh-130px)]">

          {/* Enlace de Google Maps para autocompletar ubicación */}
          <div className="bg-white p-3 rounded-xl border border-gray-200 shadow-sm">
            <label className="block font-semibold text-gray-600 mb-1 text-xs">
              Pega un enlace de Google Maps (opcional, para ubicar automáticamente)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={form.googleMapsUrl}
                onChange={setField('googleMapsUrl')}
                placeholder="https://maps.app.goo.gl/..."
                className="flex-1 px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="button"
                onClick={handleResolveLink}
                disabled={resolvingLink || !form.googleMapsUrl.trim()}
                className="px-3 py-1.5 text-xs bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition disabled:opacity-50 cursor-pointer whitespace-nowrap"
              >
                {resolvingLink ? 'Buscando...' : 'Usar enlace'}
              </button>
            </div>
          </div>

          {/* Mapa para marcar/ajustar la ubicación manualmente */}
          <div className="w-full rounded-xl overflow-hidden border border-gray-200 bg-white p-2 shadow-sm">
            <p className="text-xs text-gray-500 font-medium mb-1.5 flex items-center gap-1">
              📍 O haz clic en el mapa para marcar el centro de salud {coordinates ? '(arrastra el pin para ajustar)' : ''}:
            </p>
            <div className="w-full rounded-lg overflow-hidden h-70 relative">
              <InteractiveMap
                onOpenHospitalModal={() => {}}
                onFilterDoctorsByHospital={() => {}}
                readOnly
                pickable
                pickedLocation={coordinates}
                onPickLocation={(lat, lng) => setCoordinates({ lat, lng })}
              />
            </div>
            {!coordinates && (
              <p className="text-[11px] text-amber-600 mt-1.5">
                Sin ubicación marcada, se usará una ubicación aproximada según la ciudad al guardar.
              </p>
            )}
          </div>

          {/* Campos de datos */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-gray-700 bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <div>
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Nombre Corto *</label>
              <input
                type="text"
                value={form.name}
                onChange={setField('name')}
                placeholder="Ej. Hospital Central"
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Tipo de Centro</label>
              <select
                value={form.type}
                onChange={setField('type')}
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="publico">Público</option>
                <option value="privado">Privado / Particular</option>
                <option value="mixto">Mixto</option>
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Dirección Completa *</label>
              <input
                type="text"
                value={form.address}
                onChange={setField('address')}
                placeholder="Av. Gran Vía #450"
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Ciudad *</label>
              <input
                type="text"
                value={form.city}
                onChange={setField('city')}
                placeholder="Ej. Guadalupe"
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Zona</label>
              <input
                type="text"
                value={form.zone}
                onChange={setField('zone')}
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Teléfono de Urgencias *</label>
              <input
                type="text"
                value={form.phoneEmergency}
                onChange={setField('phoneEmergency')}
                placeholder="+52 81 4555-0100"
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Teléfono Conmutador / General</label>
              <input
                type="text"
                value={form.phoneGeneral}
                onChange={setField('phoneGeneral')}
                placeholder="+52 81 4555-0101"
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Correo</label>
              <input
                type="email"
                value={form.email}
                onChange={setField('email')}
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Sitio web</label>
              <input
                type="text"
                value={form.website}
                onChange={setField('website')}
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Persona de Contacto / Enlace</label>
              <input
                type="text"
                value={form.contactPerson}
                onChange={setField('contactPerson')}
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">No. de Congregación (territorio)</label>
              <input
                type="text"
                value={form.congregationNumber}
                onChange={setField('congregationNumber')}
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="sm:col-span-2 flex flex-wrap gap-4 pt-1">
              <label className="flex items-center gap-2 text-xs font-medium text-gray-600">
                <input type="checkbox" checked={form.pbmProtocolsAccepted} onChange={setField('pbmProtocolsAccepted')} />
                Acepta protocolos PBM
              </label>
              <label className="flex items-center gap-2 text-xs font-medium text-gray-600">
                <input type="checkbox" checked={form.acceptsBloodlessSurgery} onChange={setField('acceptsBloodlessSurgery')} />
                Acepta cirugía sin sangre
              </label>
            </div>
            <div className="sm:col-span-2">
              <label className="block font-semibold text-gray-600 mb-0.5 text-xs">Notas</label>
              <textarea
                value={form.notes}
                onChange={setField('notes')}
                rows={2}
                className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {error && (
            <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</p>
          )}
        </div>

        {/* Barra de Acciones */}
        <div className="p-3 border-t border-gray-200 flex justify-end gap-2 bg-gray-50 rounded-b-xl">
          <button type="button" onClick={onClose} className="px-4 py-1.5 text-xs bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 transition cursor-pointer">
            Cancelar
          </button>
          <button type="submit" className="px-4 py-1.5 text-xs bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium shadow-md cursor-pointer">
            {hospitalToEdit ? 'Guardar Cambios' : 'Registrar Hospital'}
          </button>
        </div>
      </form>
    </div>
  );
};
