import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { useApp } from '../context/AppContext';
import { Hospital } from '../types';
import { CONGREGATION_BOUNDARIES } from '../data/congregationBoundaries';
import { Compass } from 'lucide-react';

interface InteractiveMapProps {
  onOpenHospitalModal: (hosp?: Hospital) => void;
  onFilterDoctorsByHospital: (hospitalId: string) => void;
}

interface InteractiveMapPropsExtended extends InteractiveMapProps {
  readOnly?: boolean;
  filterByMemberEmail?: string;
  cehMembersCustom?: any[];
  /** Modo "elegir ubicación": el usuario hace clic en el mapa para colocar/mover un pin. */
  pickable?: boolean;
  /** Coordenadas actuales del pin en modo "elegir ubicación". */
  pickedLocation?: { lat: number; lng: number } | null;
  /** Se dispara con las coordenadas cuando el usuario hace clic o arrastra el pin. */
  onPickLocation?: (lat: number, lng: number) => void;
}

const DEFAULT_CONG_BOUNDARIES: Record<string, [number, number][]> = CONGREGATION_BOUNDARIES;

// Paleta de colores distintivos para diferenciar los territorios de los miembros del comité
const COLOR_PALETTE = [
  '#22c55e', '#eab308', '#ec4899', '#a855f7', '#f97316',
  '#06b6d4', '#14b8a6', '#f43f5e', '#65a30d', '#0284c7'
];

const normalize = (v: any) => v.toString().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

export const InteractiveMap: React.FC<InteractiveMapPropsExtended> = ({
  onOpenHospitalModal,
  onFilterDoctorsByHospital,
  readOnly = false,
  filterByMemberEmail,
  cehMembersCustom,
  pickable = false,
  pickedLocation = null,
  onPickLocation
}) => {
  const { hospitals, cehMembers: globalMembers } = useApp();
  const membersList = cehMembersCustom || globalMembers;

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const polygonLayersRef = useRef<L.Polygon[]>([]);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const pickMarkerRef = useRef<L.Marker | null>(null);

  // Mantener las últimas props en refs para que los listeners de Leaflet (que se
  // registran una sola vez en el mount) siempre vean el valor más reciente.
  const onPickLocationRef = useRef(onPickLocation);
  onPickLocationRef.current = onPickLocation;
  const pickableRef = useRef(pickable);
  pickableRef.current = pickable;

  const [mapCenter] = useState<[number, number]>([25.6470, -100.0960]);
  const [zoomLevel] = useState<number>(10);

  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;
    const container = mapContainerRef.current;

    // Si el contenedor todavía no tiene tamaño real (p. ej. porque el modal que lo
    // envuelve sigue en su animación de apertura, o el layout con flexbox aún no se
    // asentó), Leaflet mide 0x0 (o un tamaño incorrecto) en el momento de crear el
    // mapa y luego arrastra ese cálculo mal hecho: los tiles terminan posicionados
    // muy fuera del contenedor visible ("se desborda" / no se ve completo).
    // Por eso: 1) esperamos a que el contenedor tenga tamaño real antes de crear el
    // mapa, y 2) usamos un ResizeObserver para recalcular el tamaño cada vez que el
    // contenedor cambia (abrir/cerrar modal, animaciones, cambio de pestaña), en vez
    // de un solo setTimeout fijo que puede llegar demasiado pronto o tarde.
    let cancelled = false;
    let map: L.Map | null = null;
    let resizeObserver: ResizeObserver | null = null;

    const initMap = () => {
      if (cancelled || mapInstanceRef.current) return;
      if (container.clientWidth === 0 || container.clientHeight === 0) {
        requestAnimationFrame(initMap);
        return;
      }

      map = L.map(container).setView(mapCenter, zoomLevel);
      mapInstanceRef.current = map;

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; CEH Zona 3'
      }).addTo(map);

      markersLayerRef.current = L.layerGroup().addTo(map);

      map.on('click', (e: L.LeafletMouseEvent) => {
        if (pickableRef.current && onPickLocationRef.current) {
          onPickLocationRef.current(e.latlng.lat, e.latlng.lng);
        }
      });

      map.invalidateSize();

      resizeObserver = new ResizeObserver(() => {
        mapInstanceRef.current?.invalidateSize();
      });
      resizeObserver.observe(container);
    };

    requestAnimationFrame(initMap);

    return () => {
      cancelled = true;
      resizeObserver?.disconnect();
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Territorios (congregaciones) coloreados por miembro asignado
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    polygonLayersRef.current.forEach(layer => layer.remove());
    polygonLayersRef.current = [];

    const congToColorMap: Record<string, string> = {};
    const congToMemberNameMap: Record<string, string> = {};

    if (membersList && membersList.length > 0) {
      membersList.forEach((member, index) => {
        const assigned = member.assignedCongregationIds;
        if (assigned && Array.isArray(assigned)) {
          const memberColor = member.color || COLOR_PALETTE[index % COLOR_PALETTE.length];
          assigned.forEach((c: any) => {
            const cleanName = normalize(c);
            congToColorMap[cleanName] = memberColor;
            congToMemberNameMap[cleanName] = member.name;
          });
        }
      });
    }

    let singleAssignedCongs: string[] = [];
    if (filterByMemberEmail && membersList) {
      const target = membersList.find(m => m.email?.toLowerCase().trim() === filterByMemberEmail.toLowerCase().trim());
      if (target && target.assignedCongregationIds) {
        singleAssignedCongs = target.assignedCongregationIds.map((c: any) => normalize(c));
      }
    }

    const bounds = L.latLngBounds([]);

    Object.entries(DEFAULT_CONG_BOUNDARIES).forEach(([congName, coords]) => {
      const cleanCongName = normalize(congName);
      const isAssignedToCurrent = singleAssignedCongs.includes(cleanCongName);

      const hasOwner = !!congToColorMap[cleanCongName];
      let fillOpacity = hasOwner ? 0.5 : 0.12;
      let strokeColor = hasOwner ? congToColorMap[cleanCongName] : '#94a3b8';
      let fillColor = congToColorMap[cleanCongName] || '#94a3b8';
      const memberOwnerName = congToMemberNameMap[cleanCongName];

      if (readOnly && filterByMemberEmail) {
        if (isAssignedToCurrent) {
          fillColor = '#22c55e'; // Verde para el reporte individual
          strokeColor = '#16a34a';
          fillOpacity = 0.55;
          coords.forEach(c => bounds.extend(c));
        } else {
          fillOpacity = 0.01;
          strokeColor = '#f1f5f9';
          fillColor = '#f8fafc';
        }
      }

      if (coords && coords.length > 0) {
        const polygon = L.polygon(coords, {
          color: strokeColor,
          weight: readOnly ? 2 : (hasOwner ? 2 : 1),
          fillColor: fillColor,
          fillOpacity: fillOpacity
        }).addTo(map);

        const popupText = memberOwnerName
          ? `<b>Congregación:</b> ${congName}<br/><span style="color:#2563eb;"><b>Asignado a:</b> ${memberOwnerName}</span>`
          : `<b>Congregación:</b> ${congName}<br/><span style="color:#64748b;">Sin asignar</span>`;

        polygon.bindPopup(popupText);
        polygonLayersRef.current.push(polygon);
      }
    });

    if (readOnly && filterByMemberEmail && bounds.isValid()) {
      map.fitBounds(bounds, { padding: [20, 20] });
    }
  }, [filterByMemberEmail, membersList, readOnly]);

  // Marcadores de hospitales
  useEffect(() => {
    if (!markersLayerRef.current || !mapInstanceRef.current) return;
    markersLayerRef.current.clearLayers();

    if (hospitals && hospitals.length > 0) {
      hospitals.forEach(hosp => {
        if (hosp.coordinates?.lat && hosp.coordinates?.lng) {
          const marker = L.marker([hosp.coordinates.lat, hosp.coordinates.lng]).addTo(markersLayerRef.current!);
          marker.bindPopup(`<b>${hosp.shortName || hosp.name}</b>`);
          marker.on('click', () => onFilterDoctorsByHospital(hosp.id));
        }
      });
    }
  }, [hospitals, onFilterDoctorsByHospital]);

  // Pin de "elegir ubicación" (usado por el formulario de Hospital)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !pickable) return;

    if (!pickedLocation) {
      if (pickMarkerRef.current) {
        pickMarkerRef.current.remove();
        pickMarkerRef.current = null;
      }
      return;
    }

    if (!pickMarkerRef.current) {
      pickMarkerRef.current = L.marker([pickedLocation.lat, pickedLocation.lng], { draggable: true }).addTo(map);
      pickMarkerRef.current.on('dragend', () => {
        const pos = pickMarkerRef.current!.getLatLng();
        onPickLocationRef.current?.(pos.lat, pos.lng);
      });
    } else {
      pickMarkerRef.current.setLatLng([pickedLocation.lat, pickedLocation.lng]);
    }

    map.panTo([pickedLocation.lat, pickedLocation.lng]);
  }, [pickable, pickedLocation]);

  return (
    <div className="w-full h-full flex flex-col bg-slate-900 rounded-xl overflow-hidden border border-slate-800">
      {!readOnly && !pickable && (
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Compass className="h-5 w-5 text-blue-400" />
            <div>
              <h3 className="font-bold text-slate-200">Mapa Interactivo de Trabajo</h3>
              <p className="text-xs text-slate-400">Jurisdicción Territorial Zona 3 coloreada por miembros</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenHospitalModal()}
              className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer"
            >
              Agregar Hospital
            </button>
          </div>
        </div>
      )}
      <div className={`flex-1 relative w-full h-full min-h-[200px] bg-slate-950 ${pickable ? 'cursor-crosshair' : ''}`}>
        <div ref={mapContainerRef} className="absolute inset-0 w-full h-full" />
      </div>
    </div>
  );
};
